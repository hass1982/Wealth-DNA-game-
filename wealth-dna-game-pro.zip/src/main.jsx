
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import WealthDNAPro from './WealthDNAPro';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <WealthDNAPro />
  </React.StrictMode>
);
